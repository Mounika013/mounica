from django.apps import AppConfig


class CloudsConfig(AppConfig):
    name = 'clouds'
